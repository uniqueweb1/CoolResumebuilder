export const RESUME_ACTION_TYPES = {
    SET_SECTIONS: "resume/SET_SECTIONS",
}