export const RESUME_ACTIONS = {
    SET_SECTIONS: "resume/SET_SECTIONS"
}