import styled from "styled-components";

export const Container = styled.div`
    padding:16px;
    line-height:1.5;
`



export const Degree = styled.div`
:not(:last-of-type){
    margin-bottom:14px;
}
`