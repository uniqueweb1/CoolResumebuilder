import React from 'react';
import { SkillsSection } from './skills.styles';
import { Heading2 } from '../../simple.styles';

const Skills = () => {
  return (
    <SkillsSection>
        <Heading2>skills</Heading2>
    </SkillsSection>
  )
}

export default Skills