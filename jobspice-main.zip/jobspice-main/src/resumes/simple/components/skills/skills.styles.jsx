import styled from "styled-components";

import { Section } from "../../simple.styles";

export const SkillsSection = styled(Section)`
 background-color:yellow;
`