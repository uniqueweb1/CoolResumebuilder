import { Typography } from "@mui/material";

function Projects() {
    return (<Typography>Projects</Typography>  );
}

export default Projects;