import { Typography } from "@mui/material";

function Reference() {
    return (<Typography>Reference</Typography>  );
}

export default Reference;