import { Typography } from "@mui/material";

function Certifications() {
    return (<Typography>Certifications</Typography>  );
}

export default Certifications;