import React from 'react'

const Classic = () => {
  return (
    <div>classic.component</div>
  )
}

export default Classic