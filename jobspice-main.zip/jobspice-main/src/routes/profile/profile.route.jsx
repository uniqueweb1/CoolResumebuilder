




const Profile = () =>{
    return <p>Profile</p>
}

export default Profile;